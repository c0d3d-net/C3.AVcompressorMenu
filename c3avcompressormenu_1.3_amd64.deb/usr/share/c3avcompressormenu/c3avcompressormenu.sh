#!/usr/bin/env bash
# ==============================================================================
# C3.AVcompressorMenu - Terminal CLI Control Center
# Developer Team: C3net Development
# Binary target:  c3avcompressor
# ==============================================================================

# Determine Script Directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" 2>/dev/null && pwd)"

# Source Header / Colors if present, otherwise set built-in defaults
if [ -f "$SCRIPT_DIR/C3.AVcompressor-Header.sh" ]; then
    # shellcheck disable=SC1091
    source "$SCRIPT_DIR/C3.AVcompressor-Header.sh"
else
    # Fallback ANSI Colors
    if [ -t 1 ]; then
        BOLD='\033[1m'
        DIM='\033[2m'
        GREEN='\033[0;32m'
        RED='\033[0;31m'
        YELLOW='\033[1;33m'
        CYAN='\033[0;36m'
        BLUE='\033[0;34m'
        MAGENTA='\033[0;35m'
        WHITE='\033[1;37m'
        ORANGE='\033[38;2;255;135;0m'
        GRAD_ORANGE='\033[38;2;255;135;0m'
        GRAD_RED='\033[38;2;230;35;35m'
        GRAD_DARKRED='\033[38;2;140;20;20m'
        NC='\033[0m'
    else
        BOLD='' DIM='' GREEN='' RED='' YELLOW='' CYAN='' BLUE='' MAGENTA='' WHITE='' ORANGE=''
        GRAD_ORANGE='' GRAD_RED='' GRAD_DARKRED='' NC=''
    fi

    show_banner() {
        [ -t 1 ] && clear 2>/dev/null || true
        echo -e "${GRAD_ORANGE}░█▀▀░▀▀█░█▀█░█▀▀░▀█▀${NC}"
        echo -e "${GRAD_RED}░█░░░░▀▄░█░█░█▀▀░░█░${NC}"
        echo -e "${GRAD_DARKRED}░▀▀▀░▀▀░░▀░▀░▀▀▀░░▀░${NC}"
        echo ""
        echo -e "${BOLD}C3.AVcompressorMenu${NC}"
        echo "--------------------------------------------------------"
        echo ""
    }
fi

# Configuration Directory & File
CONFIG_DIR="$HOME/.config/c3avcompressormenu"
CONFIG_FILE="$CONFIG_DIR/config.env"

# ==============================================================================
# DEFAULT SETTINGS
# ==============================================================================
CFG_VCODEC="hevc"                    # hevc, h264, av1, vp9, prores, copy
CFG_ACODEC="aac"                     # aac, ac3, dts, wav, mp3, flac, opus, copy
CFG_PRESET="balanced"                # ultra-fast, balanced, high-quality, extreme-compression
CFG_RATE_MODE="crf"                  # crf or bitrate
CFG_CRF="23"                         # 16 - 38
CFG_VBITRATE="4500k"                 # e.g. 2000k, 4500k, 5M
CFG_ABITRATE="256k"                  # 128k, 192k, 256k, 320k
CFG_RESIZE_MODE="original"           # original, width, height, both, preset
CFG_WIDTH=""                         # e.g. 1280, 1920
CFG_HEIGHT=""                        # e.g. 720, 1080
CFG_RESOLUTION=""                    # e.g. 1920x1080, 1080p, 720p, 4k
CFG_TARGET_EXT="mp4"                 # mp4, mkv, webm, mov, original
CFG_FPS=""                           # empty or 24, 30, 60
CFG_AI_NPU="true"                    # true or false
CFG_HW_ACCEL="auto"                  # auto, videotoolbox, vaapi, nvenc, cpu
CFG_TRANSCODE_PRESET=""              # optional preset name/id
CFG_VERBOSE="false"                  # true or false

# ==============================================================================
# HELPER FUNCTIONS (Bash 3.2 & POSIX compatible)
# ==============================================================================

to_upper() {
    echo "$1" | tr '[:lower:]' '[:upper:]'
}

to_lower() {
    echo "$1" | tr '[:upper:]' '[:lower:]'
}

# Clean Path (removes quotes, unescapes spaces, expands tildes, trims trailing slashes)
clean_path() {
    local raw="$1"
    # Trim leading/trailing whitespace
    raw="$(echo "$raw" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
    # Remove outer single quotes
    raw="${raw#\'}"
    raw="${raw%\'}"
    # Remove outer double quotes
    raw="${raw#\"}"
    raw="${raw%\"}"
    # Replace escaped spaces "\ " with regular spaces
    raw="${raw//\\ / }"
    # Expand tilde ~ to $HOME
    if [[ "$raw" == "~"* ]]; then
        raw="${HOME}${raw:1}"
    fi
    # Remove trailing slash if directory (unless root /)
    if [ "$raw" != "/" ]; then
        raw="${raw%/}"
    fi
    echo "$raw"
}

# File Size in Bytes
get_file_size_bytes() {
    local f="$1"
    if [ ! -f "$f" ]; then
        echo "0"
        return
    fi
    # macOS BSD stat
    stat -f%z "$f" 2>/dev/null || stat -c%s "$f" 2>/dev/null || wc -c < "$f" | tr -d ' '
}

# Format Bytes to Human Readable
format_bytes() {
    local bytes="$1"
    if [ -z "$bytes" ] || [ "$bytes" -le 0 ] 2>/dev/null; then
        echo "0 B"
        return
    fi
    if [ "$bytes" -lt 1024 ]; then
        echo "${bytes} B"
    elif [ "$bytes" -lt 1048576 ]; then
        local kb=$((bytes / 1024))
        echo "${kb} KB"
    elif [ "$bytes" -lt 1073741824 ]; then
        # MB with 1 decimal place
        local mb=$((bytes * 10 / 1048576))
        echo "$((mb / 10)).$((mb % 10)) MB"
    else
        # GB with 2 decimal places
        local gb=$((bytes * 100 / 1073741824))
        echo "$((gb / 100)).$((gb % 100)) GB"
    fi
}

# Locate c3avcompressor binary
find_c3avcompressor() {
    if command -v c3avcompressor >/dev/null 2>&1; then
        command -v c3avcompressor
    elif [ -x "$HOME/.local/bin/c3avcompressor" ]; then
        echo "$HOME/.local/bin/c3avcompressor"
    elif [ -x "/usr/local/bin/c3avcompressor" ]; then
        echo "/usr/local/bin/c3avcompressor"
    elif [ -x "/opt/homebrew/bin/c3avcompressor" ]; then
        echo "/opt/homebrew/bin/c3avcompressor"
    elif [ -x "$SCRIPT_DIR/../c3.avcompressor.source.original/target/release/c3avcompressor" ]; then
        echo "$SCRIPT_DIR/../c3.avcompressor.source.original/target/release/c3avcompressor"
    else
        echo ""
    fi
}

# Pause helper
pause_prompt() {
    echo ""
    echo -e "${DIM}Drücken Sie die Eingabetaste [Enter], um fortzufahren...${NC}"
    read -r _
}

# Load Saved Configuration if present
load_config() {
    if [ -f "$CONFIG_FILE" ]; then
        # shellcheck disable=SC1090
        source "$CONFIG_FILE" 2>/dev/null
    fi
}

# Save Configuration
save_config() {
    mkdir -p "$CONFIG_DIR" 2>/dev/null
    cat <<EOF > "$CONFIG_FILE"
# C3.AVcompressorMenu Configuration
CFG_VCODEC="$CFG_VCODEC"
CFG_ACODEC="$CFG_ACODEC"
CFG_PRESET="$CFG_PRESET"
CFG_RATE_MODE="$CFG_RATE_MODE"
CFG_CRF="$CFG_CRF"
CFG_VBITRATE="$CFG_VBITRATE"
CFG_ABITRATE="$CFG_ABITRATE"
CFG_RESIZE_MODE="$CFG_RESIZE_MODE"
CFG_WIDTH="$CFG_WIDTH"
CFG_HEIGHT="$CFG_HEIGHT"
CFG_RESOLUTION="$CFG_RESOLUTION"
CFG_TARGET_EXT="$CFG_TARGET_EXT"
CFG_FPS="$CFG_FPS"
CFG_AI_NPU="$CFG_AI_NPU"
CFG_HW_ACCEL="$CFG_HW_ACCEL"
CFG_TRANSCODE_PRESET="$CFG_TRANSCODE_PRESET"
CFG_VERBOSE="$CFG_VERBOSE"
EOF
}

# Reset Configuration to Defaults
reset_config() {
    CFG_VCODEC="hevc"
    CFG_ACODEC="aac"
    CFG_PRESET="balanced"
    CFG_RATE_MODE="crf"
    CFG_CRF="23"
    CFG_VBITRATE="4500k"
    CFG_ABITRATE="256k"
    CFG_RESIZE_MODE="original"
    CFG_WIDTH=""
    CFG_HEIGHT=""
    CFG_RESOLUTION=""
    CFG_TARGET_EXT="mp4"
    CFG_FPS=""
    CFG_AI_NPU="true"
    CFG_HW_ACCEL="auto"
    CFG_TRANSCODE_PRESET=""
    CFG_VERBOSE="false"
    save_config
}

# Check and prompt if binary is missing
ensure_binary() {
    C3AV_BIN="$(find_c3avcompressor)"
    if [ -z "$C3AV_BIN" ] || [ ! -x "$C3AV_BIN" ]; then
        show_banner
        echo -e "${RED}${BOLD}❌ Fehler: 'c3avcompressor' Binary wurde nicht im Systempfad gefunden!${NC}"
        echo ""
        echo "Mögliche Installationsorte:"
        echo "  • ~/.local/bin/c3avcompressor"
        echo "  • /usr/local/bin/c3avcompressor"
        echo ""
        echo -e "${YELLOW}Bitte geben Sie den vollständigen Pfad zu 'c3avcompressor' ein:${NC}"
        read -r -p "Pfad: " custom_bin
        custom_bin="$(clean_path "$custom_bin")"
        if [ -x "$custom_bin" ]; then
            C3AV_BIN="$custom_bin"
        else
            echo -e "${RED}Pfad ist ungültig oder nicht ausführbar.${NC}"
            pause_prompt
            exit 1
        fi
    fi
}

# Build arguments array for compression command
build_compress_args() {
    local in_file="$1"
    local out_file="$2"
    [ -z "$C3AV_BIN" ] && C3AV_BIN="$(find_c3avcompressor)"
    CMD_ARGS=("$C3AV_BIN" "compress" "-i" "$in_file" "-o" "$out_file")

    # Transcode Preset profile override if specified
    if [ -n "$CFG_TRANSCODE_PRESET" ]; then
        CMD_ARGS+=("--transcode-preset" "$CFG_TRANSCODE_PRESET")
    fi

    # Video Codec
    CMD_ARGS+=("--video-codec" "$CFG_VCODEC")

    # Audio Codec
    CMD_ARGS+=("--audio-codec" "$CFG_ACODEC")

    # Compression Speed Preset
    CMD_ARGS+=("--preset" "$CFG_PRESET")

    # Rate Control: CRF vs Bitrate
    if [ "$CFG_RATE_MODE" = "bitrate" ] && [ -n "$CFG_VBITRATE" ]; then
        CMD_ARGS+=("-b" "$CFG_VBITRATE")
    elif [ "$CFG_RATE_MODE" = "crf" ] && [ -n "$CFG_CRF" ]; then
        CMD_ARGS+=("--crf" "$CFG_CRF")
    fi

    # Audio Bitrate
    if [ -n "$CFG_ABITRATE" ]; then
        CMD_ARGS+=("--audio-bitrate" "$CFG_ABITRATE")
    fi

    # Resolution / Scaling (width, height, width & height, or preset)
    case "$CFG_RESIZE_MODE" in
        "width")
            if [ -n "$CFG_WIDTH" ]; then
                CMD_ARGS+=("-w" "$CFG_WIDTH")
            fi
            ;;
        "height")
            if [ -n "$CFG_HEIGHT" ]; then
                CMD_ARGS+=("--height" "$CFG_HEIGHT")
            fi
            ;;
        "both"|"preset")
            if [ -n "$CFG_RESOLUTION" ]; then
                CMD_ARGS+=("--resolution" "$CFG_RESOLUTION")
            fi
            ;;
        *)
            # original, do nothing
            ;;
    esac

    # FPS
    if [ -n "$CFG_FPS" ]; then
        CMD_ARGS+=("--fps" "$CFG_FPS")
    fi

    # AI NPU
    if [ "$CFG_AI_NPU" = "true" ]; then
        CMD_ARGS+=("--ai-npu")
    fi

    # Hardware Accelerator
    if [ -n "$CFG_HW_ACCEL" ] && [ "$CFG_HW_ACCEL" != "auto" ]; then
        CMD_ARGS+=("--hw-accel" "$CFG_HW_ACCEL")
    fi

    # Verbose
    if [ "$CFG_VERBOSE" = "true" ]; then
        CMD_ARGS+=("-v")
    fi
}

# Display Active Configuration Card
show_config_card() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║${NC}  ${BOLD}${WHITE}AKTUELLE TRANSCODING- & KOMPRESSIONS-KONFIGURATION${NC}                      ${BLUE}║${NC}"
    echo -e "${BLUE}╠══════════════════════════════════════════════════════════════════════════╣${NC}"

    # Profile / Preset Line
    if [ -n "$CFG_TRANSCODE_PRESET" ]; then
        echo -e "${BLUE}║${NC}  • Profil/Preset:      ${GREEN}${BOLD}$CFG_TRANSCODE_PRESET${NC}"
    else
        echo -e "${BLUE}║${NC}  • Profil/Preset:      ${YELLOW}[Benutzerdefiniert]${NC}"
    fi

    # Video Codec & Preset
    local vc_display
    vc_display="$(to_upper "$CFG_VCODEC")"
    echo -e "${BLUE}║${NC}  • Video-Codec:        ${CYAN}${vc_display}${NC} | Preset: ${MAGENTA}${CFG_PRESET}${NC}"

    # Rate Control
    if [ "$CFG_RATE_MODE" = "bitrate" ]; then
        echo -e "${BLUE}║${NC}  • Bitrate-Modus:      ${YELLOW}Feste Bitrate: $CFG_VBITRATE${NC}"
    else
        echo -e "${BLUE}║${NC}  • Bitrate-Modus:      ${GREEN}Dynamischer CRF: $CFG_CRF (AI Dynamic Rate Control)${NC}"
    fi

    # Scaling / Video Size
    case "$CFG_RESIZE_MODE" in
        "width")
            echo -e "${BLUE}║${NC}  • Videogröße:         ${YELLOW}Breite: ${CFG_WIDTH}px (Höhe autom. proportional)${NC}"
            ;;
        "height")
            echo -e "${BLUE}║${NC}  • Videogröße:         ${YELLOW}Höhe: ${CFG_HEIGHT}px (Breite autom. proportional)${NC}"
            ;;
        "both")
            echo -e "${BLUE}║${NC}  • Videogröße:         ${YELLOW}Breite x Höhe: $CFG_RESOLUTION${NC}"
            ;;
        "preset")
            echo -e "${BLUE}║${NC}  • Videogröße:         ${YELLOW}Preset-Auflösung: $CFG_RESOLUTION${NC}"
            ;;
        *)
            echo -e "${BLUE}║${NC}  • Videogröße:         ${WHITE}Originalgröße beibehalten (100%)${NC}"
            ;;
    esac

    # Container / Audio / Acceleration
    local ext_label=".$CFG_TARGET_EXT"
    if [ "$CFG_TARGET_EXT" = "original" ]; then
        ext_label="Quellerweiterung beibehalten"
    fi
    local ac_display
    ac_display="$(to_upper "$CFG_ACODEC")"
    echo -e "${BLUE}║${NC}  • Ziel-Videotyp:      ${CYAN}${ext_label}${NC}"
    echo -e "${BLUE}║${NC}  • Audio:              ${CYAN}${ac_display}${NC} (${CFG_ABITRATE})"
    echo -e "${BLUE}║${NC}  • Hardware / NPU:     HW: ${YELLOW}${CFG_HW_ACCEL}${NC} | NPU-AI: $([ "$CFG_AI_NPU" = "true" ] && echo -e "${GREEN}Aktiviert${NC}" || echo -e "${RED}Deaktiviert${NC}")"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════════════╝${NC}"
}

# ==============================================================================
# MENU ACTIONS
# ==============================================================================

# 1) Single File Mode
action_single_file() {
    show_banner
    echo -e "${BOLD}${CYAN}🎬 EINZELNE DATEI VERARBEITEN (Single File Mode)${NC}"
    echo "--------------------------------------------------------"
    echo "Geben Sie den Pfad zur Eingabe-Videodatei ein"
    echo "(Tipp: Datei einfach per Drag & Drop ins Terminal ziehen):"
    echo -e "${DIM}[Eingabetaste leer lassen zum Abbrechen]${NC}"
    echo ""
    read -r -p "Eingabedatei: " raw_input
    local in_file
    in_file="$(clean_path "$raw_input")"

    if [ -z "$in_file" ]; then
        return
    fi

    if [ ! -f "$in_file" ]; then
        echo -e "${RED}❌ Datei existiert nicht: $in_file${NC}"
        pause_prompt
        return
    fi

    local src_dir
    src_dir="$(dirname "$in_file")"
    local filename
    filename="$(basename "$in_file")"
    local base_no_ext="${filename%.*}"
    local orig_ext="${filename##*.}"

    # Determine target extension
    local target_ext="$CFG_TARGET_EXT"
    if [ "$target_ext" = "original" ]; then
        target_ext="$orig_ext"
    fi

    # Default ReadyConv output path in the same folder as source
    local ready_dir="$src_dir/ReadyConv"
    local default_out="$ready_dir/${base_no_ext}.${target_ext}"

    echo ""
    echo -e "Quellordner:  ${WHITE}$src_dir${NC}"
    echo -e "Zieldatei:    ${GREEN}$default_out${NC}"
    echo ""
    read -r -p "Zielpfad bestätigen [Enter] oder neuen Zielpfad eingeben: " custom_out
    custom_out="$(clean_path "$custom_out")"

    local out_file="$default_out"
    if [ -n "$custom_out" ]; then
        out_file="$custom_out"
    fi

    # Create destination directory
    mkdir -p "$(dirname "$out_file")" 2>/dev/null

    # Build Command
    build_compress_args "$in_file" "$out_file"

    echo ""
    echo -e "${BOLD}${YELLOW}Geplanter Ausführungsbefehl:${NC}"
    echo -e "${DIM}${CMD_ARGS[*]}${NC}"
    echo ""
    read -r -p "Konvertierung jetzt starten? [J/n]: " confirm
    case "$confirm" in
        [nN]*)
            echo "Abgebrochen."
            pause_prompt
            return
            ;;
    esac

    local src_size
    src_size=$(get_file_size_bytes "$in_file")
    local start_ts
    start_ts=$(date +%s)

    echo ""
    echo -e "${GREEN}▶ Starte Kompression von '$filename'...${NC}"
    echo "--------------------------------------------------------"

    # Execute command
    "${CMD_ARGS[@]}"
    local exit_code=$?

    local end_ts
    end_ts=$(date +%s)
    local duration=$((end_ts - start_ts))

    echo "--------------------------------------------------------"
    if [ $exit_code -eq 0 ] && [ -f "$out_file" ]; then
        local out_size
        out_size=$(get_file_size_bytes "$out_file")
        local saved_bytes=$((src_size - out_size))
        local percent=0
        if [ "$src_size" -gt 0 ]; then
            percent=$((saved_bytes * 100 / src_size))
        fi

        echo -e "${BOLD}${GREEN}✅ Konvertierung erfolgreich abgeschlossen in ${duration}s!${NC}"
        echo -e "   • Originalgröße:   ${WHITE}$(format_bytes "$src_size")${NC}"
        echo -e "   • Neue Dateigröße: ${GREEN}$(format_bytes "$out_size")${NC}"
        if [ "$saved_bytes" -gt 0 ]; then
            echo -e "   • Ersparnis:       ${YELLOW}$(format_bytes "$saved_bytes") (-${percent}%)${NC}"
        fi
        echo -e "   • Gespeichert in:  ${CYAN}$out_file${NC}"
    else
        echo -e "${BOLD}${RED}❌ Fehler bei der Konvertierung (Exit-Code: $exit_code)${NC}"
    fi

    pause_prompt
}

# 2) Batch Folder Mode (Scan directory, recursive or non-recursive, output to ReadyConv)
action_batch_folder() {
    show_banner
    echo -e "${BOLD}${CYAN}📁 GANZEN ORDNER SCANNEN & STAPELVERARBEITEN (Batch Folder Mode)${NC}"
    echo "--------------------------------------------------------"
    echo "Geben Sie den Pfad zum Quellordner ein"
    echo "(Tipp: Ordner einfach per Drag & Drop ins Terminal ziehen):"
    echo -e "${DIM}[Eingabetaste leer lassen zum Abbrechen]${NC}"
    echo ""
    read -r -p "Quellordner: " raw_input
    local in_dir
    in_dir="$(clean_path "$raw_input")"

    if [ -z "$in_dir" ]; then
        return
    fi

    if [ ! -d "$in_dir" ]; then
        echo -e "${RED}❌ Ordner existiert nicht: $in_dir${NC}"
        pause_prompt
        return
    fi

    echo ""
    echo -e "${BOLD}${WHITE}Suchmodus für Ordner auswählen:${NC}"
    echo "  1) Nicht-Rekursiv (nur Hauptordner, keine Unterordner)"
    echo "  2) Rekursiv (Unterordner mit durchsuchen)"
    local scan_mode_sel=""
    while true; do
        read -r -p "Auswahl [1/2, Standard: 1]: " scan_mode_sel
        scan_mode_sel="${scan_mode_sel:-1}"
        case "$scan_mode_sel" in
            1|2) break ;;
            *) echo -e "${RED}Ungültige Auswahl. Bitte 1 oder 2 eingeben.${NC}" ;;
        esac
    done

    local is_recursive="false"
    local search_depth=0

    if [ "$scan_mode_sel" = "2" ]; then
        is_recursive="true"
        echo ""
        echo -e "${BOLD}${WHITE}Suchtiefe für Unterordner festlegen:${NC}"
        echo -e "  ${CYAN}• Tiefe 1:${NC} Direkte Unterordner im Hauptordner durchsuchen"
        echo -e "  ${CYAN}• Tiefe 2:${NC} Unterordner in den Unterordnern der Tiefe 1 durchsuchen"
        echo -e "  ${CYAN}• Tiefe N:${NC} Bis zur N-ten Unterordnerebene durchsuchen"
        echo -e "  ${CYAN}• 0 / max:${NC} Unbegrenzte Tiefe (alle Unterordner vollständig)"
        while true; do
            read -r -p "Suchtiefe [Zahl eingeben, Standard: 1]: " depth_input
            depth_input="${depth_input:-1}"
            case "$depth_input" in
                0|[mM][aA][xX]|[aA][lL][lL][eE]*|[uU][nN]*)
                    search_depth=0
                    break
                    ;;
                *)
                    if [[ "$depth_input" =~ ^[1-9][0-9]*$ ]]; then
                        search_depth="$depth_input"
                        break
                    else
                        echo -e "${RED}Ungültige Eingabe. Bitte eine Zahl >= 1 oder 0 für unbegrenzt eingeben.${NC}"
                    fi
                    ;;
            esac
        done
    fi

    echo ""
    if [ "$is_recursive" = "true" ]; then
        if [ "$search_depth" -eq 0 ]; then
            echo -e "${YELLOW}Scanne Ordner '${in_dir}' rekursiv nach Videodateien (unbegrenzte Tiefe)...${NC}"
        else
            echo -e "${YELLOW}Scanne Ordner '${in_dir}' rekursiv nach Videodateien (Tiefe: ${search_depth})...${NC}"
        fi
    else
        echo -e "${YELLOW}Scanne Ordner '${in_dir}' nach Videodateien (Nicht-Rekursiv, keine Unterordner)...${NC}"
    fi

    # Build find arguments (prune any ReadyConv directories so converted files are never re-scanned)
    local find_args=("$in_dir")
    if [ "$is_recursive" = "false" ]; then
        find_args+=("-maxdepth" "1")
    elif [ "$search_depth" -gt 0 ]; then
        find_args+=("-maxdepth" "$((search_depth + 1))")
    fi

    find_args+=(
        "-name" "ReadyConv" "-prune"
        "-o"
        "-type" "f"
        "("
            "-iname" "*.mp4" "-o"
            "-iname" "*.mkv" "-o"
            "-iname" "*.mov" "-o"
            "-iname" "*.avi" "-o"
            "-iname" "*.webm" "-o"
            "-iname" "*.m4v" "-o"
            "-iname" "*.ts" "-o"
            "-iname" "*.flv" "-o"
            "-iname" "*.wmv" "-o"
            "-iname" "*.vob" "-o"
            "-iname" "*.mpg" "-o"
            "-iname" "*.mpeg" "-o"
            "-iname" "*.m2ts"
        ")"
        "-print0"
    )

    local video_files=()
    while IFS= read -r -d '' f; do
        if [ -n "$f" ]; then
            # Filter out hidden files
            local bname
            bname="$(basename "$f")"
            if [[ "$bname" == "."* ]]; then
                continue
            fi
            # Filter out files inside hidden directories or ReadyConv directories
            local rel_p="${f#"$in_dir"}"
            if [[ "$rel_p" == */.* ]] || [[ "$rel_p" == *"/ReadyConv/"* ]]; then
                continue
            fi
            video_files+=("$f")
        fi
    done < <(find "${find_args[@]}" 2>/dev/null | sort -z)

    local total_files=${#video_files[@]}
    if [ "$total_files" -eq 0 ]; then
        if [ "$is_recursive" = "true" ]; then
            local depth_label
            [ "$search_depth" -eq 0 ] && depth_label="unbegrenzt" || depth_label="$search_depth"
            echo -e "${RED}⚠️ Keine unterstützten Videodateien im Ordner '${in_dir}' (Rekursiv, Tiefe: ${depth_label}) gefunden!${NC}"
        else
            echo -e "${RED}⚠️ Keine unterstützten Videodateien im Ordner '${in_dir}' (Nicht-Rekursiv) gefunden!${NC}"
        fi
        pause_prompt
        return
    fi

    echo ""
    echo -e "${BOLD}${GREEN}Gefundene Videos ($total_files):${NC}"
    local total_orig_bytes=0
    local idx=1
    for vf in "${video_files[@]}"; do
        local fsz
        fsz=$(get_file_size_bytes "$vf")
        total_orig_bytes=$((total_orig_bytes + fsz))
        if [ "$idx" -le 10 ]; then
            if [ "$is_recursive" = "true" ]; then
                local rel_vf="${vf#"$in_dir/"}"
                echo -e "  ${CYAN}[$idx]${NC} $rel_vf ${DIM}($(format_bytes "$fsz"))${NC}"
            else
                echo -e "  ${CYAN}[$idx]${NC} $(basename "$vf") ${DIM}($(format_bytes "$fsz"))${NC}"
            fi
        fi
        ((idx++))
    done
    if [ "$total_files" -gt 10 ]; then
        echo -e "  ${DIM}... und $((total_files - 10)) weitere Dateien.${NC}"
    fi

    echo ""
    echo -e "Gesamtgröße Quelle: ${WHITE}$(format_bytes "$total_orig_bytes")${NC}"
    if [ "$is_recursive" = "true" ]; then
        local depth_info
        [ "$search_depth" -eq 0 ] && depth_info="unbegrenzt" || depth_info="$search_depth"
        echo -e "Suchmodus:          ${YELLOW}Rekursiv (Tiefe: ${depth_info})${NC}"
        echo -e "Zielordner:         ${GREEN}${BOLD}Jeweils 'ReadyConv/' im Verzeichnis der Quelldateien${NC}"
    else
        echo -e "Suchmodus:          ${YELLOW}Nicht-Rekursiv (nur Hauptordner)${NC}"
        echo -e "Zielordner:         ${GREEN}${BOLD}$in_dir/ReadyConv${NC}"
    fi
    echo -e "Ziel-Videotyp:      ${CYAN}.${CFG_TARGET_EXT}${NC}"
    echo ""

    # Show preview of command for file #1
    local sample_first="${video_files[0]}"
    local sample_bname
    sample_bname="$(basename "$sample_first")"
    local sample_no_ext="${sample_bname%.*}"
    local sample_ext="$CFG_TARGET_EXT"
    if [ "$sample_ext" = "original" ]; then
        sample_ext="${sample_bname##*.}"
    fi
    local sample_dir
    sample_dir="$(dirname "$sample_first")"
    build_compress_args "$sample_first" "$sample_dir/ReadyConv/${sample_no_ext}.${sample_ext}"
    echo -e "${BOLD}${YELLOW}Beispiel-Befehl für Datei 1:${NC}"
    echo -e "${DIM}${CMD_ARGS[*]}${NC}"
    echo ""

    read -r -p "Bereits in 'ReadyConv/' existierende Zieldateien überschreiben? [J/n]: " ow_confirm
    local skip_existing="false"
    case "$ow_confirm" in
        [nN]*) skip_existing="true" ;;
    esac

    read -r -p "Möchten Sie die Stapelverarbeitung für alle $total_files Videos starten? [J/n]: " confirm
    case "$confirm" in
        [nN]*)
            echo "Abgebrochen."
            pause_prompt
            return
            ;;
    esac

    # Ensure ReadyConv destination directories exist in all affected folders
    if [ "$is_recursive" = "true" ]; then
        for vf in "${video_files[@]}"; do
            mkdir -p "$(dirname "$vf")/ReadyConv" 2>/dev/null
        done
    else
        mkdir -p "$in_dir/ReadyConv" 2>/dev/null
    fi

    local processed_count=0
    local success_count=0
    local skip_count=0
    local fail_count=0
    local total_conv_bytes=0
    local start_batch_ts
    start_batch_ts=$(date +%s)

    echo ""
    echo -e "${BOLD}${GREEN}▶ Starte Stapelverarbeitung...${NC}"
    echo "========================================================"

    for vf in "${video_files[@]}"; do
        ((processed_count++))
        local vf_dir
        vf_dir="$(dirname "$vf")"
        local item_ready_dir="$vf_dir/ReadyConv"
        mkdir -p "$item_ready_dir" 2>/dev/null

        local v_bname
        v_bname="$(basename "$vf")"
        local v_no_ext="${v_bname%.*}"
        local v_ext="$CFG_TARGET_EXT"
        if [ "$v_ext" = "original" ]; then
            v_ext="${v_bname##*.}"
        fi
        local out_target="$item_ready_dir/${v_no_ext}.${v_ext}"

        echo ""
        echo -e "${BOLD}${CYAN}▶ [$processed_count/$total_files] Verarbeite: ${WHITE}$v_bname${NC}"
        if [ "$is_recursive" = "true" ]; then
            local rel_dir="${vf_dir#"$in_dir"}"
            rel_dir="${rel_dir#/}" # remove leading slash if any
            if [ -n "$rel_dir" ]; then
                echo -e "  ↳ Unterordner: ${YELLOW}$rel_dir${NC}"
                echo -e "  ↳ Ziel:        ${GREEN}$rel_dir/ReadyConv/${v_no_ext}.${v_ext}${NC}"
            else
                echo -e "  ↳ Ziel:        ${GREEN}ReadyConv/${v_no_ext}.${v_ext}${NC}"
            fi
        else
            echo -e "  ↳ Ziel: ${GREEN}ReadyConv/${v_no_ext}.${v_ext}${NC}"
        fi

        if [ -f "$out_target" ] && [ "$skip_existing" = "true" ]; then
            echo -e "  ${YELLOW}↷ Überspringe: Datei existiert bereits in ReadyConv.${NC}"
            local cur_out_sz
            cur_out_sz=$(get_file_size_bytes "$out_target")
            total_conv_bytes=$((total_conv_bytes + cur_out_sz))
            ((skip_count++))
            continue
        fi

        local cur_src_sz
        cur_src_sz=$(get_file_size_bytes "$vf")
        local item_start_ts
        item_start_ts=$(date +%s)

        build_compress_args "$vf" "$out_target"
        "${CMD_ARGS[@]}"
        local item_exit=$?

        local item_end_ts
        item_end_ts=$(date +%s)
        local item_dur=$((item_end_ts - item_start_ts))

        if [ $item_exit -eq 0 ] && [ -f "$out_target" ]; then
            local cur_out_sz
            cur_out_sz=$(get_file_size_bytes "$out_target")
            total_conv_bytes=$((total_conv_bytes + cur_out_sz))
            local item_saved=$((cur_src_sz - cur_out_sz))
            local item_pct=0
            if [ "$cur_src_sz" -gt 0 ]; then
                item_pct=$((item_saved * 100 / cur_src_sz))
            fi

            echo -e "  ${GREEN}✓ Fertig in ${item_dur}s:${NC} $(format_bytes "$cur_src_sz") ➔ $(format_bytes "$cur_out_sz") ${YELLOW}(-${item_pct}%)${NC}"
            ((success_count++))
        else
            echo -e "  ${RED}✗ Fehler bei Datei '$v_bname' (Exit-Code: $item_exit)${NC}"
            ((fail_count++))
        fi
    done

    local end_batch_ts
    end_batch_ts=$(date +%s)
    local total_batch_dur=$((end_batch_ts - start_batch_ts))

    local total_saved_bytes=$((total_orig_bytes - total_conv_bytes))
    local total_pct=0
    if [ "$total_orig_bytes" -gt 0 ]; then
        total_pct=$((total_saved_bytes * 100 / total_orig_bytes))
    fi

    echo ""
    echo -e "${BLUE}========================================================================${NC}"
    echo -e "${BOLD}${GREEN}🎉 BATCH-VERARBEITUNG ABGESCHLOSSEN${NC}"
    echo -e "${BLUE}========================================================================${NC}"
    echo -e " • Verarbeitet:       ${WHITE}$processed_count von $total_files Dateien${NC}"
    echo -e " • Erfolgreich:       ${GREEN}$success_count${NC}"
    [ "$skip_count" -gt 0 ] && echo -e " • Übersprungen:      ${YELLOW}$skip_count${NC}"
    echo -e " • Fehlgeschlagen:    ${RED}$fail_count${NC}"
    echo -e " • Gesamtdauer:       ${YELLOW}${total_batch_dur} Sekunden${NC}"
    echo -e " • Quellgröße gesamt: ${WHITE}$(format_bytes "$total_orig_bytes")${NC}"
    echo -e " • Zielgröße gesamt:  ${GREEN}$(format_bytes "$total_conv_bytes")${NC}"
    if [ "$total_saved_bytes" -gt 0 ]; then
        echo -e " • Speicherersparnis: ${YELLOW}${BOLD}$(format_bytes "$total_saved_bytes") (-${total_pct}%)${NC}"
    fi
    if [ "$is_recursive" = "true" ]; then
        local depth_summary
        [ "$search_depth" -eq 0 ] && depth_summary="unbegrenzt" || depth_summary="$search_depth"
        echo -e " • Suchmodus:         ${CYAN}Rekursiv (Tiefe: ${depth_summary})${NC}"
        echo -e " • Zielordner:        ${CYAN}Jeweils 'ReadyConv/' in den jeweiligen Quellordnern${NC}"
    else
        echo -e " • Suchmodus:         ${CYAN}Nicht-Rekursiv${NC}"
        echo -e " • Zielordner:        ${CYAN}$in_dir/ReadyConv${NC}"
    fi
    echo -e "${BLUE}========================================================================${NC}"

    pause_prompt
}

# 3) Video & Transcoding Configuration Submenu
action_configure_options() {
    while true; do
        show_banner
        show_config_card
        echo ""
        echo -e "${BOLD}${WHITE}PARAMETEREINSTELLUNGEN:${NC}"
        echo "  1) 🎥 Video-Codec ändern                [Aktuell: $CFG_VCODEC]"
        echo "  2) 📐 Videogröße & Skalierung ändern     [Aktuell: $CFG_RESIZE_MODE]"
        echo "  3) 🎯 Bitrate / CRF Qualitätsmodus       [Aktuell: $CFG_RATE_MODE ($([ "$CFG_RATE_MODE" = "bitrate" ] && echo "$CFG_VBITRATE" || echo "CRF $CFG_CRF"))]"
        echo "  4) ⚡ Komprimierungs-Preset (Speed)      [Aktuell: $CFG_PRESET]"
        echo "  5) 🎵 Audio-Codec ändern                [Aktuell: $CFG_ACODEC]"
        echo "  6) 🔊 Audio-Bitrate ändern              [Aktuell: $CFG_ABITRATE]"
        echo "  7) 📦 Ziel-Videotyp / Container (.ext)  [Aktuell: .$CFG_TARGET_EXT]"
        echo "  8) 🎞️ Bildwiederholrate (FPS)           [Aktuell: $([ -n "$CFG_FPS" ] && echo "$CFG_FPS" || echo "Original")]"
        echo "  9) 🧠 AI / NPU Beschleunigung           [Aktuell: $([ "$CFG_AI_NPU" = "true" ] && echo "Aktiv" || echo "Aus")]"
        echo " 10) ⚙️ Hardware-Beschleuniger             [Aktuell: $CFG_HW_ACCEL]"
        echo " 11) 💬 Ausführliche Ausgabe (Verbose)     [Aktuell: $CFG_VERBOSE]"
        echo " 12) 🔄 Auf Standardeinstellungen zurücksetzen"
        echo "  0) ⬅️ Zurück zum Hauptmenü"
        echo ""
        read -r -p "Wahl [0-12]: " opt_choice

        case "$opt_choice" in
            1)
                echo ""
                echo "Wählen Sie den Video-Codec:"
                echo "  1) hevc   - H.265 / Apple VideoToolbox / NPU (Empfohlen, hocheffizient)"
                echo "  2) h264   - H.264 / AVC (Universelle Kompatibilität für alle Geräte)"
                echo "  3) av1    - SVT-AV1 Next-Gen Open Codec"
                echo "  4) vp9    - Google VP9 Web Codec"
                echo "  5) prores - Apple ProRes (Professioneller Schnitt / Studio)"
                echo "  6) copy   - Lossless Stream-Copy (0% Neuberechnung, blitzschnell)"
                read -r -p "Auswahl [1-6]: " vc_sel
                case "$vc_sel" in
                    1) CFG_VCODEC="hevc" ;;
                    2) CFG_VCODEC="h264" ;;
                    3) CFG_VCODEC="av1" ;;
                    4) CFG_VCODEC="vp9" ;;
                    5) CFG_VCODEC="prores" ;;
                    6) CFG_VCODEC="copy" ;;
                esac
                CFG_TRANSCODE_PRESET=""
                save_config
                ;;
            2)
                echo ""
                echo "Wählen Sie die gewünschte Video-Skalierung:"
                echo "  1) Originalgröße beibehalten (Keine Skalierung)"
                echo "  2) Breite festlegen (Höhe wird proportional autom. berechnet, z.B. 1280)"
                echo "  3) Höhe festlegen (Breite wird proportional autom. berechnet, z.B. 720)"
                echo "  4) Breite und Höhe festlegen (z.B. 1920x1080)"
                echo "  5) Standard Preset-Auflösung (1080p, 720p, 4k, 480p)"
                read -r -p "Auswahl [1-5]: " sz_sel
                case "$sz_sel" in
                    1)
                        CFG_RESIZE_MODE="original"
                        CFG_WIDTH=""
                        CFG_HEIGHT=""
                        CFG_RESOLUTION=""
                        ;;
                    2)
                        echo ""
                        read -r -p "Ziel-Breite in Pixeln eingeben [z.B. 1920, 1280, 854]: " in_w
                        if [ -n "$in_w" ]; then
                            CFG_RESIZE_MODE="width"
                            CFG_WIDTH="$in_w"
                            CFG_HEIGHT=""
                            CFG_RESOLUTION=""
                        fi
                        ;;
                    3)
                        echo ""
                        read -r -p "Ziel-Höhe in Pixeln eingeben [z.B. 1080, 720, 480]: " in_h
                        if [ -n "$in_h" ]; then
                            CFG_RESIZE_MODE="height"
                            CFG_HEIGHT="$in_h"
                            CFG_WIDTH=""
                            CFG_RESOLUTION=""
                        fi
                        ;;
                    4)
                        echo ""
                        read -r -p "Ziel-Breite in Pixeln eingeben [z.B. 1920]: " in_w
                        read -r -p "Ziel-Höhe in Pixeln eingeben   [z.B. 1080]: " in_h
                        if [ -n "$in_w" ] && [ -n "$in_h" ]; then
                            CFG_RESIZE_MODE="both"
                            CFG_RESOLUTION="${in_w}x${in_h}"
                            CFG_WIDTH=""
                            CFG_HEIGHT=""
                        fi
                        ;;
                    5)
                        echo ""
                        echo "Presets: 1) 1080p  2) 720p  3) 4k  4) 480p"
                        read -r -p "Auswahl [1-4]: " p_res
                        case "$p_res" in
                            1) CFG_RESOLUTION="1080p" ;;
                            2) CFG_RESOLUTION="720p" ;;
                            3) CFG_RESOLUTION="4k" ;;
                            4) CFG_RESOLUTION="480p" ;;
                        esac
                        CFG_RESIZE_MODE="preset"
                        CFG_WIDTH=""
                        CFG_HEIGHT=""
                        ;;
                esac
                CFG_TRANSCODE_PRESET=""
                save_config
                ;;
            3)
                echo ""
                echo "Bitrate- / Qualitäts-Steuerung:"
                echo "  1) Dynamischer CRF-Qualitätsmodus (Empfohlen, NPU berechnet adaptive Bitrate)"
                echo "  2) Feste Video-Bitrate festlegen (z.B. 2000k, 4500k, 5M)"
                read -r -p "Auswahl [1-2]: " br_choice
                if [ "$br_choice" = "1" ]; then
                    CFG_RATE_MODE="crf"
                    echo ""
                    read -r -p "CRF-Wert eingeben (16-38, Standard 23, niedrig=bessere Qualität): [23] " in_crf
                    CFG_CRF="${in_crf:-23}"
                elif [ "$br_choice" = "2" ]; then
                    CFG_RATE_MODE="bitrate"
                    echo ""
                    read -r -p "Ziel-Bitrate eingeben (z.B. 2000k, 4500k, 5M): [4500k] " in_br
                    CFG_VBITRATE="${in_br:-4500k}"
                fi
                CFG_TRANSCODE_PRESET=""
                save_config
                ;;
            4)
                echo ""
                echo "Komprimierungs-Preset (Geschwindigkeit vs. Kompressionsrate):"
                echo "  1) ultra-fast          - Maximaler Durchsatz, schnelles Skip-Pruning"
                echo "  2) balanced            - Optimale Balance Geschwindigkeit/Qualität (~38% Ersparnis)"
                echo "  3) high-quality        - Priorisiert Bildfeinheiten in Fokuszonen"
                echo "  4) extreme-compression - Aggressive neuronale Quantisierung (bis zu 48% Ersparnis)"
                read -r -p "Auswahl [1-4]: " pr_sel
                case "$pr_sel" in
                    1) CFG_PRESET="ultra-fast" ;;
                    2) CFG_PRESET="balanced" ;;
                    3) CFG_PRESET="high-quality" ;;
                    4) CFG_PRESET="extreme-compression" ;;
                esac
                CFG_TRANSCODE_PRESET=""
                save_config
                ;;
            5)
                echo ""
                echo "Wählen Sie den Audio-Codec:"
                echo "  1) aac  (Standard, hohe Kompatibilität)"
                echo "  2) ac3  (Dolby Digital 5.1 / Surround)"
                echo "  3) dts  (DTS Audio)"
                echo "  4) wav  (Unkomprimiertes Lossless PCM)"
                echo "  5) mp3  (MPEG Layer 3)"
                echo "  6) flac (Lossless Audio)"
                echo "  7) opus (Hocheffizient bei niedrigen Bitraten)"
                echo "  8) copy (Original-Tonspur 1:1 übernehmen)"
                read -r -p "Auswahl [1-8]: " ac_sel
                case "$ac_sel" in
                    1) CFG_ACODEC="aac" ;;
                    2) CFG_ACODEC="ac3" ;;
                    3) CFG_ACODEC="dts" ;;
                    4) CFG_ACODEC="wav" ;;
                    5) CFG_ACODEC="mp3" ;;
                    6) CFG_ACODEC="flac" ;;
                    7) CFG_ACODEC="opus" ;;
                    8) CFG_ACODEC="copy" ;;
                esac
                CFG_TRANSCODE_PRESET=""
                save_config
                ;;
            6)
                echo ""
                echo "Wählen Sie die Audio-Bitrate:"
                echo "  1) 128k (Kompakt / Sprache)"
                echo "  2) 192k (Standard)"
                echo "  3) 256k (Hochwertig / Empfohlen)"
                echo "  4) 320k (Maximale AAC/MP3 Qualität)"
                echo "  5) Benutzerdefiniert"
                read -r -p "Auswahl [1-5]: " abr_sel
                case "$abr_sel" in
                    1) CFG_ABITRATE="128k" ;;
                    2) CFG_ABITRATE="192k" ;;
                    3) CFG_ABITRATE="256k" ;;
                    4) CFG_ABITRATE="320k" ;;
                    5)
                        read -r -p "Eigene Bitrate (z.B. 96k, 384k, 640k): " custom_abr
                        if [ -n "$custom_abr" ]; then
                            CFG_ABITRATE="$custom_abr"
                        fi
                        ;;
                esac
                CFG_TRANSCODE_PRESET=""
                save_config
                ;;
            7)
                echo ""
                echo "Wählen Sie den Ziel-Videotyp (Container-Erweiterung):"
                echo "  1) mp4      - Standard MP4 Container (Beste Kompatibilität)"
                echo "  2) mkv      - Matroska MKV Container (Unterstützt alle Spuren/Codecs)"
                echo "  3) webm     - WebM Container (Optimal für Web/Browser)"
                echo "  4) mov      - Apple QuickTime MOV"
                echo "  5) original - Quell-Dateiendung beibehalten"
                read -r -p "Auswahl [1-5]: " ext_sel
                case "$ext_sel" in
                    1) CFG_TARGET_EXT="mp4" ;;
                    2) CFG_TARGET_EXT="mkv" ;;
                    3) CFG_TARGET_EXT="webm" ;;
                    4) CFG_TARGET_EXT="mov" ;;
                    5) CFG_TARGET_EXT="original" ;;
                esac
                save_config
                ;;
            8)
                echo ""
                read -r -p "Ziel-Framerate (FPS) eingeben (z.B. 24, 30, 60, oder leer für Original): " in_fps
                CFG_FPS="$in_fps"
                save_config
                ;;
            9)
                if [ "$CFG_AI_NPU" = "true" ]; then
                    CFG_AI_NPU="false"
                else
                    CFG_AI_NPU="true"
                fi
                save_config
                ;;
            10)
                echo ""
                echo "Wählen Sie den Hardware-Beschleuniger:"
                echo "  1) auto         - Automatische Erkennung"
                echo "  2) videotoolbox - Apple Silicon & Intel Mac VideoToolbox"
                echo "  3) vaapi        - Linux VA-API (Intel/AMD)"
                echo "  4) nvenc        - NVIDIA NVENC"
                echo "  5) cpu          - Reines Software-Encoding (CPU)"
                read -r -p "Auswahl [1-5]: " hw_sel
                case "$hw_sel" in
                    1) CFG_HW_ACCEL="auto" ;;
                    2) CFG_HW_ACCEL="videotoolbox" ;;
                    3) CFG_HW_ACCEL="vaapi" ;;
                    4) CFG_HW_ACCEL="nvenc" ;;
                    5) CFG_HW_ACCEL="cpu" ;;
                esac
                save_config
                ;;
            11)
                if [ "$CFG_VERBOSE" = "true" ]; then
                    CFG_VERBOSE="false"
                else
                    CFG_VERBOSE="true"
                fi
                save_config
                ;;
            12)
                reset_config
                echo -e "${GREEN}Standardeinstellungen wiederhergestellt!${NC}"
                sleep 1
                ;;
            0)
                break
                ;;
            *)
                echo -e "${RED}Ungültige Eingabe.${NC}"
                sleep 1
                ;;
        esac
    done
}

# 4) Transcoding Preset Selector
action_select_preset() {
    show_banner
    echo -e "${BOLD}${CYAN}⚡ TRANSCODING-PRESET AUSWÄHLEN${NC}"
    echo "--------------------------------------------------------"
    echo "Wählen Sie ein vordefiniertes Transcoding-Profil:"
    echo "  1) enc_hevc_balanced   - Apple Silicon HEVC Balanced (Empfohlen, ~38% Ersparnis)"
    echo "  2) enc_hevc_ultrafast  - HEVC Ultra-Fast (Maximaler Durchsatz für Großmengen)"
    echo "  3) enc_hevc_hq_1080p   - HEVC High-Quality 1080p (Archivierung mit CRF 20 & 320k Audio)"
    echo "  4) enc_hevc_extreme    - HEVC Extreme Compression (-48% Bitrate, Opus Audio)"
    echo "  5) enc_h264_compat     - H.264 Universelle Kompatibilität für ältere Player"
    echo "  6) enc_prores          - Apple ProRes Master / Schnittstudio (PCM Audio)"
    echo "  7) enc_stream_copy     - Lossless Stream-Copy (0% Neuberechnung, Re-Mux)"
    echo "  8) enc_custom_1790113198 - C3 720p H264 2000k (Proportionale Höhe)"
    echo "  9) Eigenen Preset-Namen / ID manuell eingeben"
    echo "  0) Abbrechen"
    echo ""
    read -r -p "Auswahl [0-9]: " p_choice

    case "$p_choice" in
        1)
            CFG_TRANSCODE_PRESET="enc_hevc_balanced"
            CFG_VCODEC="hevc"; CFG_ACODEC="aac"; CFG_PRESET="balanced"; CFG_RATE_MODE="crf"; CFG_CRF="23"
            CFG_ABITRATE="256k"; CFG_RESIZE_MODE="original"; CFG_TARGET_EXT="mp4"
            ;;
        2)
            CFG_TRANSCODE_PRESET="enc_hevc_ultrafast"
            CFG_VCODEC="hevc"; CFG_ACODEC="aac"; CFG_PRESET="ultra-fast"; CFG_RATE_MODE="crf"; CFG_CRF="24"
            CFG_ABITRATE="192k"; CFG_RESIZE_MODE="original"; CFG_TARGET_EXT="mp4"
            ;;
        3)
            CFG_TRANSCODE_PRESET="enc_hevc_hq_1080p"
            CFG_VCODEC="hevc"; CFG_ACODEC="aac"; CFG_PRESET="balanced"; CFG_RATE_MODE="crf"; CFG_CRF="20"
            CFG_ABITRATE="320k"; CFG_RESIZE_MODE="preset"; CFG_RESOLUTION="1080p"; CFG_TARGET_EXT="mp4"
            ;;
        4)
            CFG_TRANSCODE_PRESET="enc_hevc_extreme"
            CFG_VCODEC="hevc"; CFG_ACODEC="opus"; CFG_PRESET="extreme-compression"; CFG_RATE_MODE="crf"; CFG_CRF="26"
            CFG_ABITRATE="128k"; CFG_RESIZE_MODE="original"; CFG_TARGET_EXT="mkv"
            ;;
        5)
            CFG_TRANSCODE_PRESET="enc_h264_compat"
            CFG_VCODEC="h264"; CFG_ACODEC="aac"; CFG_PRESET="balanced"; CFG_RATE_MODE="crf"; CFG_CRF="22"
            CFG_ABITRATE="192k"; CFG_RESIZE_MODE="original"; CFG_TARGET_EXT="mp4"
            ;;
        6)
            CFG_TRANSCODE_PRESET="enc_prores"
            CFG_VCODEC="prores"; CFG_ACODEC="wav"; CFG_PRESET="balanced"; CFG_RATE_MODE="crf"; CFG_CRF="18"
            CFG_ABITRATE="1411k"; CFG_RESIZE_MODE="original"; CFG_TARGET_EXT="mov"
            ;;
        7)
            CFG_TRANSCODE_PRESET="enc_stream_copy"
            CFG_VCODEC="copy"; CFG_ACODEC="copy"; CFG_PRESET="ultra-fast"; CFG_RATE_MODE="crf"; CFG_CRF="23"
            CFG_RESIZE_MODE="original"; CFG_TARGET_EXT="mp4"
            ;;
        8)
            CFG_TRANSCODE_PRESET="enc_custom_1790113198"
            CFG_VCODEC="h264"; CFG_ACODEC="aac"; CFG_PRESET="balanced"; CFG_RATE_MODE="bitrate"; CFG_VBITRATE="2000k"
            CFG_ABITRATE="192k"; CFG_RESIZE_MODE="width"; CFG_WIDTH="1280"; CFG_TARGET_EXT="mp4"
            ;;
        9)
            echo ""
            read -r -p "Preset-Name oder ID eingeben: " custom_pname
            if [ -n "$custom_pname" ]; then
                CFG_TRANSCODE_PRESET="$custom_pname"
            fi
            ;;
        0)
            return
            ;;
    esac

    save_config
    echo ""
    echo -e "${GREEN}✓ Preset '${CFG_TRANSCODE_PRESET}' erfolgreich aktiviert!${NC}"
    pause_prompt
}

# 5) Split Mode
action_split_media() {
    show_banner
    echo -e "${BOLD}${CYAN}✂️ VIDEO SCHNEIDEN / TEILEN (Split Mode)${NC}"
    echo "--------------------------------------------------------"
    echo "Geben Sie die Mediendatei ein (oder per Drag & Drop):"
    read -r -p "Eingabedatei: " raw_input
    local in_file
    in_file="$(clean_path "$raw_input")"

    if [ -z "$in_file" ] || [ ! -f "$in_file" ]; then
        echo -e "${RED}Ungültige Eingabedatei.${NC}"
        pause_prompt
        return
    fi

    local src_dir
    src_dir="$(dirname "$in_file")"
    local fname
    fname="$(basename "$in_file")"
    local bname_no_ext="${fname%.*}"
    local ext="${fname##*.}"
    local ready_dir="$src_dir/ReadyConv"
    mkdir -p "$ready_dir" 2>/dev/null

    echo ""
    echo "Wählen Sie den Schnitt-Modus:"
    echo "  1) Zeitbereich zuschneiden (Start- und Endzeitstempel)"
    echo "  2) Dauer ab Start zuschneiden (z.B. erste 60 Sekunden)"
    echo "  3) In gleich lange Segmente aufteilen (z.B. alle 300s)"
    echo "  4) AI Automatische Szenenerkennung (Schnitt bei Szenenwechseln)"
    read -r -p "Auswahl [1-4]: " split_mode

    local split_cmd=("$C3AV_BIN" "split" "-i" "$in_file")
    local default_out=""

    case "$split_mode" in
        1)
            read -r -p "Startzeit (z.B. 00:01:30 oder 90s): " start_t
            read -r -p "Endzeit   (z.B. 00:05:00 oder 300s): " end_t
            default_out="$ready_dir/${bname_no_ext}_clip.${ext}"
            read -r -p "Zieldatei [$default_out]: " custom_out
            local out_file="${custom_out:-$default_out}"
            out_file="$(clean_path "$out_file")"
            split_cmd+=("-o" "$out_file")
            [ -n "$start_t" ] && split_cmd+=("--start" "$start_t")
            [ -n "$end_t" ] && split_cmd+=("--end" "$end_t")
            ;;
        2)
            read -r -p "Startzeit (z.B. 00:00:00 oder 0): [00:00:00] " start_t
            start_t="${start_t:-00:00:00}"
            read -r -p "Dauer     (z.B. 60s oder 5m): " dur_t
            default_out="$ready_dir/${bname_no_ext}_part.${ext}"
            read -r -p "Zieldatei [$default_out]: " custom_out
            local out_file="${custom_out:-$default_out}"
            out_file="$(clean_path "$out_file")"
            split_cmd+=("-o" "$out_file" "--start" "$start_t")
            [ -n "$dur_t" ] && split_cmd+=("-d" "$dur_t")
            ;;
        3)
            read -r -p "Segment-Dauer (z.B. 300s oder 10m): " seg_t
            default_out="$ready_dir/${bname_no_ext}_part_%03d.${ext}"
            read -r -p "Ziel-Muster [$default_out]: " custom_out
            local out_file="${custom_out:-$default_out}"
            out_file="$(clean_path "$out_file")"
            split_cmd+=("-o" "$out_file")
            [ -n "$seg_t" ] && split_cmd+=("--segment-time" "$seg_t")
            ;;
        4)
            default_out="$ready_dir/${bname_no_ext}_scene_%03d.${ext}"
            read -r -p "Ziel-Muster [$default_out]: " custom_out
            local out_file="${custom_out:-$default_out}"
            out_file="$(clean_path "$out_file")"
            split_cmd+=("-o" "$out_file" "--ai-scene-split")
            ;;
        *)
            echo "Abgebrochen."
            return
            ;;
    esac

    echo ""
    read -r -p "Lossless Stream-Copy verwenden (blitzschnell, 0% Re-Encode)? [J/n]: " use_copy
    case "$use_copy" in
        [nN]*) ;;
        *) split_cmd+=("--copy") ;;
    esac

    echo ""
    echo -e "${YELLOW}Befehl: ${split_cmd[*]}${NC}"
    echo ""
    "${split_cmd[@]}"
    local ec=$?

    if [ $ec -eq 0 ]; then
        echo -e "${GREEN}✅ Schneiden erfolgreich beendet! Gespeichert in ReadyConv.${NC}"
    else
        echo -e "${RED}❌ Fehler beim Schneiden (Exit-Code: $ec)${NC}"
    fi
    pause_prompt
}

# 6) Extract Mode
action_extract_media() {
    show_banner
    echo -e "${BOLD}${CYAN}🎵 SPUREN EXTRAHIEREN (Audio / Video Extract Mode)${NC}"
    echo "--------------------------------------------------------"
    echo "Geben Sie die Mediendatei ein (oder per Drag & Drop):"
    read -r -p "Eingabedatei: " raw_input
    local in_file
    in_file="$(clean_path "$raw_input")"

    if [ -z "$in_file" ] || [ ! -f "$in_file" ]; then
        echo -e "${RED}Ungültige Eingabedatei.${NC}"
        pause_prompt
        return
    fi

    local src_dir
    src_dir="$(dirname "$in_file")"
    local fname
    fname="$(basename "$in_file")"
    local bname_no_ext="${fname%.*}"
    local ready_dir="$src_dir/ReadyConv"
    mkdir -p "$ready_dir" 2>/dev/null

    echo ""
    echo "Was möchten Sie extrahieren?"
    echo "  1) Audio-Tonspur (MP3, AAC, AC3, DTS, WAV, FLAC, Opus)"
    echo "  2) Reine Videospur ohne Ton (Video Mute)"
    read -r -p "Auswahl [1-2]: " ext_type

    local ext_cmd=("$C3AV_BIN" "extract" "-i" "$in_file")

    if [ "$ext_type" = "1" ]; then
        echo ""
        echo "Ziel-Audioformat wählen:"
        echo "  1) mp3   (320k / MP3)"
        echo "  2) aac   (AAC Audio)"
        echo "  3) ac3   (Dolby Digital)"
        echo "  4) wav   (Lossless unkomprimiert)"
        echo "  5) flac  (Lossless FLAC)"
        echo "  6) opus  (Opus Audio)"
        echo "  7) copy  (Original-Audiobitstrom 1:1 kopieren)"
        read -r -p "Auswahl [1-7]: " af_choice
        local afmt="mp3"
        local acopy=false
        case "$af_choice" in
            1) afmt="mp3" ;;
            2) afmt="aac" ;;
            3) afmt="ac3" ;;
            4) afmt="wav" ;;
            5) afmt="flac" ;;
            6) afmt="opus" ;;
            7) afmt="copy"; acopy=true ;;
        esac

        local default_out="$ready_dir/${bname_no_ext}.${afmt}"
        read -r -p "Ziel-Audiodatei [$default_out]: " custom_out
        local out_file="${custom_out:-$default_out}"
        out_file="$(clean_path "$out_file")"

        ext_cmd+=("-o" "$out_file" "--stream-type" "audio")
        if [ "$acopy" = "true" ]; then
            ext_cmd+=("--copy")
        else
            ext_cmd+=("--format" "$afmt")
            read -r -p "Audio-Bitrate (z.B. 320k, 256k, 192k) [Standard: 320k]: " a_br
            a_br="${a_br:-320k}"
            ext_cmd+=("-b" "$a_br")
        fi
    elif [ "$ext_type" = "2" ]; then
        local default_out="$ready_dir/${bname_no_ext}_video.mp4"
        read -r -p "Ziel-Videodatei [$default_out]: " custom_out
        local out_file="${custom_out:-$default_out}"
        out_file="$(clean_path "$out_file")"
        ext_cmd+=("-o" "$out_file" "--stream-type" "video" "--copy")
    else
        return
    fi

    echo ""
    echo -e "${YELLOW}Befehl: ${ext_cmd[*]}${NC}"
    echo ""
    "${ext_cmd[@]}"
    local ec=$?

    if [ $ec -eq 0 ]; then
        echo -e "${GREEN}✅ Extraktion erfolgreich abgeschlossen! Gespeichert in ReadyConv.${NC}"
    else
        echo -e "${RED}❌ Fehler bei der Extraktion (Exit-Code: $ec)${NC}"
    fi
    pause_prompt
}

# 7) Mux Mode
action_mux_media() {
    show_banner
    echo -e "${BOLD}${CYAN}🔀 VIDEO & AUDIO ZUSAMMENFÜGEN (Mux Mode)${NC}"
    echo "--------------------------------------------------------"
    read -r -p "Eingabe-Videodatei: " raw_v
    local in_v
    in_v="$(clean_path "$raw_v")"
    if [ -z "$in_v" ] || [ ! -f "$in_v" ]; then
        echo -e "${RED}Ungültige Videodatei.${NC}"
        pause_prompt
        return
    fi

    read -r -p "Eingabe-Audiodatei: " raw_a
    local in_a
    in_a="$(clean_path "$raw_a")"
    if [ -z "$in_a" ] || [ ! -f "$in_a" ]; then
        echo -e "${RED}Ungültige Audiodatei.${NC}"
        pause_prompt
        return
    fi

    local src_dir
    src_dir="$(dirname "$in_v")"
    local fname
    fname="$(basename "$in_v")"
    local bname_no_ext="${fname%.*}"
    local ready_dir="$src_dir/ReadyConv"
    mkdir -p "$ready_dir" 2>/dev/null

    echo ""
    echo "Container-Format wählen:"
    echo "  1) MP4 (.mp4)"
    echo "  2) Matroska (.mkv)"
    echo "  3) WebM (.webm)"
    read -r -p "Auswahl [1-3]: " c_choice
    local c_ext="mp4"
    case "$c_choice" in
        1) c_ext="mp4" ;;
        2) c_ext="mkv" ;;
        3) c_ext="webm" ;;
    esac

    local default_out="$ready_dir/${bname_no_ext}_muxed.${c_ext}"
    read -r -p "Zieldatei [$default_out]: " custom_out
    local out_file="${custom_out:-$default_out}"
    out_file="$(clean_path "$out_file")"

    local mux_cmd=("$C3AV_BIN" "mux" "--video" "$in_v" "--audio" "$in_a" "--output" "$out_file" "--copy")

    echo ""
    echo -e "${YELLOW}Befehl: ${mux_cmd[*]}${NC}"
    echo ""
    "${mux_cmd[@]}"
    local ec=$?

    if [ $ec -eq 0 ]; then
        echo -e "${GREEN}✅ Muxing erfolgreich abgeschlossen! Gespeichert in ReadyConv.${NC}"
    else
        echo -e "${RED}❌ Fehler beim Muxing (Exit-Code: $ec)${NC}"
    fi
    pause_prompt
}

# 8) Probe Media
action_probe_media() {
    show_banner
    echo -e "${BOLD}${CYAN}🔍 MEDIENDATEI ANALYSIEREN (Probe File)${NC}"
    echo "--------------------------------------------------------"
    read -r -p "Mediendatei eingeben (oder Drag & Drop): " raw_input
    local in_file
    in_file="$(clean_path "$raw_input")"

    if [ -z "$in_file" ] || [ ! -f "$in_file" ]; then
        echo -e "${RED}Ungültige Datei.${NC}"
        pause_prompt
        return
    fi

    echo ""
    echo "Ausgabeformat:"
    echo "  1) Formatierte Übersicht"
    echo "  2) Strukturiertes JSON"
    read -r -p "Wahl [1-2]: " p_fmt

    echo ""
    if [ "$p_fmt" = "2" ]; then
        "$C3AV_BIN" probe -i "$in_file" --json
    else
        "$C3AV_BIN" probe -i "$in_file"
    fi
    pause_prompt
}

# 9) NPU Status
action_npu_status() {
    show_banner
    echo -e "${BOLD}${CYAN}🧠 NPU- & HARDWARE-STATUS${NC}"
    echo "--------------------------------------------------------"
    "$C3AV_BIN" npu-status
    pause_prompt
}

# 10) Benchmark
action_benchmark() {
    show_banner
    echo -e "${BOLD}${CYAN}🚀 NPU DURCHSATZ-BENCHMARK${NC}"
    echo "--------------------------------------------------------"
    echo "Wählen Sie die Benchmark-Auflösung:"
    echo "  1) 1080p (Full HD)"
    echo "  2) 4k    (Ultra HD)"
    read -r -p "Auswahl [1-2]: " b_res
    local res_str="1080p"
    if [ "$b_res" = "2" ]; then
        res_str="4k"
    fi

    read -r -p "Testdauer in Sekunden [Standard: 5]: " b_dur
    local dur_val="${b_dur:-5}"

    echo ""
    "$C3AV_BIN" benchmark --resolution "$res_str" --duration "$dur_val"
    pause_prompt
}

# 11) Presets Listing
action_list_presets() {
    show_banner
    echo -e "${BOLD}${CYAN}📜 VERFÜGBARE PRESETS IM SYSTEM${NC}"
    echo "--------------------------------------------------------"
    "$C3AV_BIN" presets
    pause_prompt
}

# ==============================================================================
# MAIN EVENT LOOP
# ==============================================================================
main() {
    # Trap Ctrl+C cleanly
    trap 'echo ""; echo "C3.AVcompressorMenu beendet."; exit 0' SIGINT

    # Handle CLI flags
    if [ "$1" = "-V" ] || [ "$1" = "--version" ]; then
        echo "C3.AVcompressorMenu 1.3"
        echo "Developer Team: C3net Development (C0D3D-NET)"
        echo "Target Systems: macOS (Apple Silicon M1-M4 & Intel) & Linux (x86_64, aarch64)"
        exit 0
    fi
    if [ "$1" = "-h" ] || [ "$1" = "--help" ]; then
        echo "C3.AVcompressorMenu - Terminal CLI Control Center v1.3"
        echo "Developer Team: C3net Development"
        echo ""
        echo "USAGE:"
        echo "    c3avcompressormenu [OPTIONS]"
        echo "    c3avmenu [OPTIONS]"
        echo ""
        echo "OPTIONS:"
        echo "    -h, --help       Print this help message"
        echo "    -V, --version    Print version information"
        echo ""
        echo "DESCRIPTION:"
        echo "    Launches the interactive terminal control center for C3.AVcompressor."
        echo "    Features single-file and recursive/non-recursive batch directory transcoding,"
        echo "    automatic 'ReadyConv' subfolder placement, NPU AI optimization,"
        echo "    video scaling, bitrate tuning, audio extraction, splitting, and muxing."
        exit 0
    fi

    ensure_binary
    load_config

    while true; do
        show_banner
        show_config_card
        echo ""
        echo -e "${BOLD}${WHITE}[HAUPTMENÜ]${NC}"
        echo -e "  ${BOLD}${GREEN}1)${NC} 🎬 Einzelne Video-Datei komprimieren / konvertieren"
        echo -e "  ${BOLD}${GREEN}2)${NC} 📁 ${BOLD}Ganzen Ordner scannen & stapelverarbeiten (Batch -> 'ReadyConv')${NC}"
        echo -e "  ${BOLD}${CYAN}3)${NC} ⚙️  Video- & Transcoding-Optionen konfigurieren (Codec, Bitrate, Größe...)"
        echo -e "  ${BOLD}${CYAN}4)${NC} ⚡ Transcoding-Preset laden / auswählen (Apple HEVC, ProRes, Web...)"
        echo -e "  ${BOLD}${YELLOW}5)${NC} ✂️  Video schneiden & teilen (Split Mode: Zeitbereich, Segmente, AI-Scene)"
        echo -e "  ${BOLD}${YELLOW}6)${NC} 🎵 Tonspur / Videospur extrahieren (Extract Mode: MP3, AAC, AC3, WAV...)"
        echo -e "  ${BOLD}${YELLOW}7)${NC} 🔀 Video & Audio zusammenfügen (Mux Mode)"
        echo -e "  ${BOLD}${MAGENTA}8)${NC} 🔍 Mediendatei analysieren (Probe File)"
        echo -e "  ${BOLD}${MAGENTA}9)${NC} 🧠 NPU & Hardware-Status anzeigen (NPU-Status / TOPS)"
        echo -e "  ${BOLD}${MAGENTA}10)${NC} 🚀 NPU Durchsatz-Benchmark ausführen (1080p / 4K)"
        echo -e "  ${BOLD}${WHITE}11)${NC} 📜 Alle System-Presets auflisten (Presets List)"
        echo -e "  ${BOLD}${WHITE}12)${NC} 🔄 Konfiguration auf Standard zurücksetzen"
        echo -e "  ${BOLD}${RED}0)${NC} 🚪 Beenden"
        echo ""
        read -r -p "Bitte Option wählen [0-12]: " main_choice

        case "$main_choice" in
            1)  action_single_file ;;
            2)  action_batch_folder ;;
            3)  action_configure_options ;;
            4)  action_select_preset ;;
            5)  action_split_media ;;
            6)  action_extract_media ;;
            7)  action_mux_media ;;
            8)  action_probe_media ;;
            9)  action_npu_status ;;
            10) action_benchmark ;;
            11) action_list_presets ;;
            12) reset_config; echo -e "${GREEN}Standardeinstellungen geladen!${NC}"; sleep 1 ;;
            0|q|exit)
                show_banner
                echo -e "${ORANGE}Auf Wiedersehen! Vielen Dank für die Nutzung von C3.AVcompressor.${NC}"
                echo -e "${RED}C3net Development.${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}Ungültige Auswahl. Bitte Zahl zwischen 0 und 12 eingeben.${NC}"
                sleep 1
                ;;
        esac
    done
}

# Run Main if executed directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
