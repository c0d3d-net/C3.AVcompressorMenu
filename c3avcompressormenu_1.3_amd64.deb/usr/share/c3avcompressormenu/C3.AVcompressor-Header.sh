# ==============================================================================
# C3.AVcompressor
# by C3net Development
#
# ANSI Color Codes
if [ -t 1 ]; then
    BOLD='\033[1m'   
    GREEN='\033[0;32m'
    RED='\033[0;31m'
    YELLOW='\033[1;33m'
    CYAN='\033[0;36m'
    BLUE='\033[0;34m'
    GRAD_ORANGE='\033[38;2;255;135;0m'
    GRAD_RED='\033[38;2;230;35;35m'
    GRAD_DARKRED='\033[38;2;140;20;20m'
    NC='\033[0m' # No Color
else
    BOLD=''
    GREEN=''
    RED='' 
    YELLOW=''
    CYAN=''
    BLUE=''
    GRAD_ORANGE=''
    GRAD_RED=''
    GRAD_DARKRED=''
    NC=''
fi
    
# Print Header Banner
show_banner() {
    [ -t 1 ] && clear 2>/dev/null || true
    printf "%b\n" "${GRAD_ORANGE}░█▀▀░▀▀█░█▀█░█▀▀░▀█▀${NC}"
    printf "%b\n" "${GRAD_RED}░█░░░░▀▄░█░█░█▀▀░░█░${NC}"
    printf "%b\n" "${GRAD_DARKRED}░▀▀▀░▀▀░░▀░▀░▀▀▀░░▀░${NC}"
    printf "\n"
    printf "%b\n" "${BOLD}C3.AVcompressor Menu${NC}"
    printf "\n"
}
show_banner
    echo "--------------------------------------------------------\n"
